Student submission should be copied under this directory to run all the tests.
